@echo off
title Faxina Rapida 13/11-B
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo.
  echo  Vou pedir permissao de ADMINISTRADOR.
  echo  Na janela do Windows que vai aparecer, clique em SIM.
  echo  ^(Se clicar em Nao, abre do mesmo jeito, so que com menos opcoes.^)
  echo.
  powershell -NoProfile -Command "try { Start-Process -FilePath '%~f0' -Verb RunAs -ErrorAction Stop; exit 0 } catch { exit 1 }"
  if not errorlevel 1 exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0faxina.ps1"
pause
