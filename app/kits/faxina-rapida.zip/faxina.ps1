﻿# FAXINA RAPIDA 13/11-B - feita para o Maikon. Roda no PowerShell que ja vem no Windows (nao instala nada).
# Regras: so OLHA sem perguntar. Apagar so temporarios e Lixeira, e so depois de voce digitar SIM duas vezes.
# Nunca apaga seus documentos. Nunca formata. Copiar para o HD nao apaga nada daqui.
$ErrorActionPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$host.UI.RawUI.WindowTitle = 'Faxina Rápida 13/11-B'
$Pasta = Join-Path $env:USERPROFILE 'Faxina-Rapida'
New-Item -ItemType Directory -Force -Path $Pasta | Out-Null
$Rel = Join-Path $Pasta ('relatorio-' + (Get-Date -Format 'yyyy-MM-dd-HHmm') + '.txt')

function Diga($t) { Write-Host $t; Add-Content -LiteralPath $Rel -Value $t -Encoding UTF8 }
function GB($b) { if (-not $b) { $b = 0 }; return ('{0:N1} GB' -f ($b / 1GB)) }
function Tam($p) {
  if (-not (Test-Path -LiteralPath $p)) { return 0 }
  $s = (Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
  if ($s) { return $s } else { return 0 }
}
function SouAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Confirma2($o) {
  Write-Host ''
  Write-Host $o -ForegroundColor Yellow
  $a = Read-Host 'Para confirmar, digite SIM (ou so aperte Enter para desistir)'
  if ($a -ne 'SIM') { Write-Host 'Desisti. Nada foi feito.' -ForegroundColor Cyan; return $false }
  $b = Read-Host 'Tem certeza? Digite SIM de novo'
  if ($b -ne 'SIM') { Write-Host 'Desisti. Nada foi feito.' -ForegroundColor Cyan; return $false }
  return $true
}
function Livre { return (Get-PSDrive -Name C).Free }
function Espera { Write-Host ''; Read-Host 'Aperte Enter para voltar ao menu' | Out-Null }

function Olhar {
  Diga ''
  Diga ('===== RELATORIO DA FAXINA - ' + (Get-Date -Format 'dd/MM/yyyy HH:mm') + ' =====')
  Diga ('Administrador: ' + $(if (SouAdmin) { 'SIM' } else { 'NAO' }))
  Diga ''
  Diga '--- Discos ---'
  Get-PSDrive -PSProvider FileSystem | ForEach-Object {
    if ($_.Used -or $_.Free) { Diga ('  ' + $_.Name + ':  usado ' + (GB $_.Used) + ' | livre ' + (GB $_.Free)) }
  }
  Diga ''
  Diga '--- Suas pastas (pode demorar uns minutos, estou medindo) ---'
  $lista = @()
  Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Force | ForEach-Object {
    Write-Host ('  medindo ' + $_.Name + '...') -ForegroundColor DarkGray
    $lista += [pscustomobject]@{ Nome = $_.Name; Bytes = (Tam $_.FullName) }
  }
  $lista | Sort-Object Bytes -Descending | Select-Object -First 15 | ForEach-Object { Diga ('  ' + (GB $_.Bytes).PadLeft(10) + '  ' + $_.Nome) }
  Diga ''
  Diga '--- Dentro do AppData\Local (onde programas guardam coisas escondidas) ---'
  $loc = @()
  Get-ChildItem -LiteralPath $env:LOCALAPPDATA -Directory -Force | ForEach-Object { $loc += [pscustomobject]@{ Nome = $_.Name; Bytes = (Tam $_.FullName) } }
  $loc | Sort-Object Bytes -Descending | Select-Object -First 10 | ForEach-Object { Diga ('  ' + (GB $_.Bytes).PadLeft(10) + '  ' + $_.Nome) }
  Diga ''
  Diga '--- Coisas do Windows que ocupam muito ---'
  $h = Get-Item -LiteralPath 'C:\hiberfil.sys' -Force
  if ($h) { Diga ('  Hibernacao (hiberfil.sys): ' + (GB $h.Length) + '  -> opcao 4 libera isso') }
  $pg = Get-Item -LiteralPath 'C:\pagefile.sys' -Force
  if ($pg) { Diga ('  Memoria virtual (pagefile.sys): ' + (GB $pg.Length) + '  (deixe como esta)') }
  if (Test-Path 'C:\Windows.old') { Diga ('  Windows.old (Windows antigo): ' + (GB (Tam 'C:\Windows.old')) + '  -> opcao 5 (Limpeza de Disco) remove') }
  Diga ('  Temporarios seus: ' + (GB (Tam $env:TEMP)) + '  -> opcao 2')
  $lix = 0
  try { (New-Object -ComObject Shell.Application).NameSpace(10).Items() | ForEach-Object { $lix += $_.Size } } catch {}
  Diga ('  Lixeira: ' + (GB $lix) + '  -> opcao 3')
  $dfs = Join-Path $env:LOCALAPPDATA 'Google\DriveFS'
  if (Test-Path $dfs) { Diga ('  Sobra do Google Drive (DriveFS): ' + (GB (Tam $dfs)) + '  -> NAO apague antes da opcao 7 (achados e perdidos)') }
  Diga ''
  Diga '--- Os 25 maiores arquivos nas suas pastas (acima de 300 MB) ---'
  Get-ChildItem -LiteralPath $env:USERPROFILE -Recurse -Force -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Length -gt 300MB } | Sort-Object Length -Descending | Select-Object -First 25 |
    ForEach-Object { Diga ('  ' + (GB $_.Length).PadLeft(10) + '  ' + $_.FullName) }
  Diga ''
  Diga ('Relatorio salvo em: ' + $Rel)
  Diga 'Mande esse arquivo (ou um print) para o Claude. Nada foi apagado.'
}

function Saude {
  Diga ''
  Diga ('===== SAUDE DO PC - ' + (Get-Date -Format 'dd/MM/yyyy HH:mm') + ' (so olha, nao muda nada) =====')
  Diga ('Administrador: ' + $(if (SouAdmin) { 'SIM' } else { 'NAO' }))
  $os = Get-CimInstance Win32_OperatingSystem
  if ($os) {
    Diga ('Windows: ' + $os.Caption + ' | ligado desde ' + $os.LastBootUpTime)
    Diga ('Memoria: usando ' + ('{0:N1}' -f (($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB)) + ' GB de ' + ('{0:N1}' -f ($os.TotalVisibleMemorySize / 1MB)) + ' GB')
  }
  Diga ''
  Diga '--- Saude dos discos (o proprio disco diz se esta bem) ---'
  Get-PhysicalDisk | ForEach-Object { Diga ('  ' + $_.FriendlyName + ' | ' + $_.MediaType + ' | saude: ' + $_.HealthStatus + ' | estado: ' + $_.OperationalStatus) }
  Diga ''
  Diga '--- Os 12 programas que mais gastam memoria agora ---'
  Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 12 | ForEach-Object { Diga ('  ' + ('{0:N0} MB' -f ($_.WorkingSet64 / 1MB)).PadLeft(9) + '  ' + $_.ProcessName) }
  Diga ''
  Diga '--- Programas que ligam sozinhos com o Windows ---'
  Get-CimInstance Win32_StartupCommand | ForEach-Object { Diga ('  ' + $_.Name + '  (' + $_.Location + ')') }
  Diga '  (Para desligar algum: Ctrl+Shift+Esc > aba Inicializar > botao direito > Desabilitar)'
  Diga ''
  Diga '--- Programas usando a internet / portas abertas agora ---'
  $vistos = @{}
  Get-NetTCPConnection -State Listen,Established | ForEach-Object {
    $pr = (Get-Process -Id $_.OwningProcess).ProcessName
    $k = $pr + '|' + $_.State
    if (-not $vistos.ContainsKey($k)) { $vistos[$k] = 0 }
    $vistos[$k]++
  }
  $vistos.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 30 | ForEach-Object {
    $a = $_.Key.Split('|')
    Diga ('  ' + $a[0] + ' -> ' + $(if ($a[1] -eq 'Listen') { 'esperando conexao (porta aberta)' } else { 'conectado na internet' }) + ' (' + $_.Value + 'x)')
  }
  Diga ''
  Diga '--- Servicos da Microsoft que mandam dados (telemetria) ---'
  foreach ($n in 'DiagTrack', 'dmwappushservice', 'WerSvc') {
    $sv = Get-Service -Name $n
    if ($sv) { Diga ('  ' + $sv.DisplayName + ' (' + $n + '): ' + $sv.Status + ' | inicio: ' + $sv.StartType) }
  }
  Diga '  (DiagTrack e o servico de telemetria. Estar rodando e normal no Windows; o Claude explica se vale desligar.)'
  Diga ''
  Diga '--- Atualizacoes ---'
  $hf = Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 3
  foreach ($x in $hf) { Diga ('  ' + $x.HotFixID + ' instalada em ' + $x.InstalledOn) }
  Diga ''
  Diga '--- Antivirus (Windows Defender) ---'
  $mp = Get-MpComputerStatus
  if ($mp) { Diga ('  Ligado: ' + $mp.AntivirusEnabled + ' | protecao em tempo real: ' + $mp.RealTimeProtectionEnabled + ' | vacinas de ' + $mp.AntivirusSignatureLastUpdated) }
  Diga ''
  Diga '--- Impressoras instaladas ---'
  Get-Printer | ForEach-Object { Diga ('  ' + $_.Name + ' | driver: ' + $_.DriverName + ' | porta: ' + $_.PortName + ' | ' + $_.PrinterStatus) }
  Diga ''
  Diga ('Relatorio salvo em: ' + $Rel)
  Diga 'Mande para o Claude. Nada foi mudado.'
}

function Repetidos {
  Write-Host 'Vou procurar arquivos REPETIDOS (iguais por dentro) em Documentos, Area de Trabalho e Downloads.'
  Write-Host 'So faz uma LISTA. Nao apaga nada. Pode demorar.' -ForegroundColor Cyan
  $pastas = @([Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Downloads'))
  $arqs = foreach ($pp in $pastas) { Get-ChildItem -LiteralPath $pp -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 100KB } }
  $grupos = $arqs | Group-Object Length | Where-Object { $_.Count -gt 1 }
  $sobra = 0; $n = 0
  Diga ''
  Diga '===== ARQUIVOS REPETIDOS (o primeiro de cada grupo fica; os outros sao copias) ====='
  foreach ($g in $grupos) {
    $porHash = $g.Group | ForEach-Object { [pscustomobject]@{ F = $_; H = (Get-FileHash -LiteralPath $_.FullName -Algorithm MD5).Hash } } | Group-Object H | Where-Object { $_.Count -gt 1 -and $_.Name }
    foreach ($h in $porHash) {
      $n++
      $sobra += $h.Group[0].F.Length * ($h.Count - 1)
      Diga ('Grupo ' + $n + ' (' + (GB $h.Group[0].F.Length) + ' cada):')
      $h.Group | ForEach-Object { Diga ('   ' + $_.F.FullName) }
    }
  }
  Diga ('Total: ' + $n + ' grupos de repetidos. Apagando as copias liberaria cerca de ' + (GB $sobra) + '.')
  Diga 'Mande esta lista para o Claude antes de apagar qualquer coisa.'
}

function LimparTemp {
  $antes = Livre
  $t = Tam $env:TEMP
  $w = 0; if (SouAdmin) { $w = Tam 'C:\Windows\Temp' }
  Write-Host ('Temporarios seus: ' + (GB $t) + $(if (SouAdmin) { ' | do Windows: ' + (GB $w) } else { ' | (os do Windows precisam de administrador)' }))
  if (-not (Confirma2 'Vou apagar SO os arquivos temporarios (lixo que os programas deixam). Seus documentos nao sao tocados. Arquivos em uso ficam.')) { return }
  Get-ChildItem -LiteralPath $env:TEMP -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  if (SouAdmin) { Get-ChildItem -LiteralPath 'C:\Windows\Temp' -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
  Diga ('Temporarios limpos. Liberou cerca de ' + (GB ((Livre) - $antes)) + '.')
}

function Lixeira {
  $lix = 0
  try { (New-Object -ComObject Shell.Application).NameSpace(10).Items() | ForEach-Object { $lix += $_.Size } } catch {}
  Write-Host ('Lixeira tem ' + (GB $lix) + '.')
  Write-Host 'ANTES: abra a Lixeira e veja se nao tem arquivo de cliente la dentro. Se tiver, clique com o botao direito e Restaurar.' -ForegroundColor Yellow
  $ab = Read-Host 'Quer que eu abra a Lixeira para voce olhar primeiro? (S/N)'
  if ($ab -match '^[sS]') { Start-Process 'shell:RecycleBinFolder'; Read-Host 'Olhou? Aperte Enter para continuar' | Out-Null }
  if (-not (Confirma2 'Vou ESVAZIAR a Lixeira. O que esta nela some de vez.')) { return }
  $antes = Livre
  Clear-RecycleBin -Force -ErrorAction SilentlyContinue
  Diga ('Lixeira esvaziada. Liberou cerca de ' + (GB ((Livre) - $antes)) + '.')
}

function Hibernacao {
  if (-not (SouAdmin)) { Write-Host 'Isso precisa de administrador. Feche e abra pelo ABRIR-FAXINA.bat clicando SIM na janela do Windows.' -ForegroundColor Yellow; return }
  $h = Get-Item -LiteralPath 'C:\hiberfil.sys' -Force
  if (-not $h) { Write-Host 'A hibernacao ja esta desligada.'; return }
  Write-Host ('A hibernacao ocupa ' + (GB $h.Length) + '. Desligar nao estraga nada: o PC so deixa de ter a opcao Hibernar.')
  Write-Host 'Para ligar de novo um dia: powercfg /h on'
  $a = Read-Host 'Desligar a hibernacao? Digite SIM'
  if ($a -ne 'SIM') { Write-Host 'Nada foi feito.'; return }
  $antes = Livre
  powercfg /h off
  Start-Sleep -Seconds 2
  Diga ('Hibernacao desligada. Liberou cerca de ' + (GB ((Livre) - $antes)) + '.')
}

function LimpezaWindows {
  Write-Host 'Vou abrir a Limpeza de Disco do proprio Windows.'
  Write-Host 'Nela: clique em "Limpar arquivos do sistema", marque tudo MENOS "Downloads", e clique OK.' -ForegroundColor Yellow
  Start-Process cleanmgr.exe -ArgumentList '/d C'
  Diga 'Abri a Limpeza de Disco do Windows.'
}

function Copiar {
  Write-Host 'Unidades que eu achei (HD externo / pendrive aparecem aqui):'
  $u = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -ne 'C' -and ($_.Used -or $_.Free) }
  if (-not $u) { Write-Host 'Nao achei nenhum HD externo ou pendrive. Ligue o HD, espere 30 segundos e tente de novo.' -ForegroundColor Yellow; Write-Host 'Se ele nunca aparece: aperte Windows+X > Gerenciamento de Disco e tire um print para o Claude.'; return }
  $u | ForEach-Object { Write-Host ('  ' + $_.Name + ':  livre ' + (GB $_.Free)) }
  $d = (Read-Host 'Digite a LETRA do HD (ex.: E)').Trim().TrimEnd(':').ToUpper()
  if (-not (Test-Path ($d + ':\'))) { Write-Host 'Essa letra nao existe.'; return }
  $op = @{ '1' = [Environment]::GetFolderPath('MyDocuments'); '2' = [Environment]::GetFolderPath('Desktop'); '3' = (Join-Path $env:USERPROFILE 'Downloads'); '4' = [Environment]::GetFolderPath('MyPictures'); '5' = [Environment]::GetFolderPath('MyVideos'); '6' = (Join-Path $env:USERPROFILE 'OneDrive') }
  Write-Host '1 Documentos | 2 Area de Trabalho | 3 Downloads | 4 Imagens | 5 Videos | 6 OneDrive | 7 outra pasta'
  $e = Read-Host 'Qual pasta copiar?'
  if ($e -eq '7') { $src = (Read-Host 'Cole o caminho da pasta').Trim('"') } else { $src = $op[$e] }
  if (-not $src -or -not (Test-Path -LiteralPath $src)) { Write-Host 'Nao achei essa pasta.'; return }
  $dst = Join-Path ($d + ':\Backup-PC-Maikon') (Split-Path $src -Leaf)
  Write-Host ('Copiando ' + $src + '  ->  ' + $dst)
  Write-Host 'Isto so COPIA. Nada sai daqui. Pode demorar.' -ForegroundColor Cyan
  robocopy "$src" "$dst" /E /R:1 /W:1 /XJ /NP /TEE /LOG+:"$Pasta\copia.log"
  $a = (Get-ChildItem -LiteralPath $src -Recurse -Force -File | Measure-Object).Count
  $b = (Get-ChildItem -LiteralPath $dst -Recurse -Force -File | Measure-Object).Count
  Diga ('Copia: ' + $src + ' -> ' + $dst + ' | arquivos aqui: ' + $a + ' | la no HD: ' + $b)
  if ($b -ge $a) { Diga 'OK: todos os arquivos estao no HD.' } else { Diga 'ATENCAO: faltaram arquivos. Rode de novo (ele continua de onde parou) ou mande o copia.log para o Claude.' }
}

function AchadosDrive {
  $raiz = Join-Path $env:LOCALAPPDATA 'Google\DriveFS'
  $achou = Get-ChildItem -LiteralPath $raiz -Directory -Recurse -Force -Filter 'lost_and_found' -ErrorAction SilentlyContinue
  if (-not $achou) { Write-Host 'Nao achei a pasta de achados e perdidos do Google Drive.'; Diga 'Achados e perdidos do Drive: nao encontrado.'; return }
  foreach ($p in $achou) {
    $n = (Get-ChildItem -LiteralPath $p.FullName -Recurse -Force -File | Measure-Object).Count
    Diga ('Achados e perdidos do Drive: ' + $p.FullName + ' | ' + $n + ' arquivos | ' + (GB (Tam $p.FullName)))
    Start-Process explorer.exe -ArgumentList ('"' + $p.FullName + '"')
  }
  Write-Host 'Abri a pasta. Se tiver arquivo de cliente, use a opcao 6 (outra pasta) para COPIAR essa pasta para o HD.' -ForegroundColor Yellow
}

while ($true) {
  Clear-Host
  Write-Host '==============================================' -ForegroundColor Cyan
  Write-Host '   FAXINA RAPIDA 13/11-B  -  livre no C: ' (GB (Livre)) -ForegroundColor Cyan
  Write-Host ('   Administrador: ' + $(if (SouAdmin) { 'SIM' } else { 'NAO (algumas opcoes ficam limitadas)' }))
  Write-Host '==============================================' -ForegroundColor Cyan
  Write-Host ' 1  Olhar o que esta enchendo o PC (so olha, faz relatorio)'
  Write-Host ' S  SAUDE do PC: memoria, discos, portas, internet, telemetria, antivirus, impressoras (so olha)'
  Write-Host ' R  Procurar arquivos REPETIDOS (so faz a lista)'
  Write-Host ' 2  Limpar arquivos temporarios (pede SIM duas vezes)'
  Write-Host ' 3  Esvaziar a Lixeira (deixa voce olhar antes)'
  Write-Host ' 4  Desligar a hibernacao (libera varios GB)'
  Write-Host ' 5  Abrir a Limpeza de Disco do Windows'
  Write-Host ' 6  COPIAR uma pasta para o HD externo / pendrive'
  Write-Host ' 7  Achados e perdidos do Google Drive (arquivos sumidos)'
  Write-Host ' 8  Abrir a lista de programas (para desinstalar)'
  Write-Host ' 9  Abrir a pasta dos relatorios'
  Write-Host ' 0  Sair'
  $c = Read-Host 'Digite o numero'
  switch ($c) {
    '1' { Olhar; Espera }
    { $_ -in 's','S' } { Saude; Espera }
    { $_ -in 'r','R' } { Repetidos; Espera }
    '2' { LimparTemp; Espera }
    '3' { Lixeira; Espera }
    '4' { Hibernacao; Espera }
    '5' { LimpezaWindows; Espera }
    '6' { Copiar; Espera }
    '7' { AchadosDrive; Espera }
    '8' { Start-Process appwiz.cpl; Write-Host 'Abri. Clique no programa que nao usa e em Desinstalar.'; Espera }
    '9' { Start-Process explorer.exe -ArgumentList ('"' + $Pasta + '"') }
    '0' { exit }
  }
}
