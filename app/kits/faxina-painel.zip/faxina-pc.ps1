﻿# FAXINA PC - PAINEL 13/11 (feito para o Maikon)
# Liga um painel no navegador (so neste PC) com: Saude, Pastas, Programas, Repetidos, Virus, HD e portas,
# Receber do celular pelo Wi-Fi, Terminal de verdade e o Ajudante (IA).
# Nao instala nada. Nunca formata. Apagar so com SIM duas vezes, e documentos vao primeiro para a Quarentena.
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$Aqui = Split-Path -Parent $PSCommandPath
$Casa = Join-Path $env:USERPROFILE 'Faxina-PC'
New-Item -ItemType Directory -Force -Path $Casa | Out-Null
$Registro = Join-Path $Casa 'registro.txt'
function Log($t) { try { Add-Content -LiteralPath $Registro -Value ((Get-Date -Format 'dd/MM HH:mm:ss') + ' ' + $t) -Encoding UTF8 } catch {} }
function SouAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (SouAdmin)) {
  Write-Host ''
  Write-Host '  Vou pedir permissao de ADMINISTRADOR. Na janela do Windows, clique em SIM.' -ForegroundColor Yellow
  try {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ErrorAction Stop -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File', ('"' + $PSCommandPath + '"'))
    exit 0
  } catch {
    Write-Host '  Voce clicou Nao (ou o Windows nao deixou). Vou abrir assim mesmo, com menos poderes.' -ForegroundColor Yellow
  }
}

$host.UI.RawUI.WindowTitle = 'Faxina PC - NAO FECHE esta janela enquanto usa o painel'
$Token = -join ((48..57) + (97..122) | Get-Random -Count 24 | ForEach-Object { [char]$_ })
$Codigo = '{0:D6}' -f (Get-Random -Minimum 100000 -Maximum 999999)
$script:Recebendo = $false
$script:PastaCel = Join-Path $env:USERPROFILE 'Backup-Celular'
$script:Jobs = @{}
$Quarentena = Join-Path $Casa 'Quarentena'

function GB($b) { if (-not $b) { $b = 0 }; return ('{0:N1} GB' -f ($b / 1GB)) }
function Tam($p) {
  if (-not (Test-Path -LiteralPath $p)) { return 0 }
  $s = (Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
  if ($s) { return [double]$s } else { return 0 }
}
function Livre { return [double](Get-PSDrive -Name C).Free }
function Lista($x) { return @($x | Where-Object { $_ -ne $null }) }

# ---------- respostas ----------
function Enviar($ctx, $code, [byte[]]$bytes, $tipo) {
  $r = $ctx.Response
  $r.StatusCode = $code
  $r.ContentType = $tipo
  $r.Headers['Cache-Control'] = 'no-store'
  $r.ContentLength64 = $bytes.Length
  $r.OutputStream.Write($bytes, 0, $bytes.Length)
  $r.OutputStream.Close()
}
function Json($ctx, $obj, $code = 200) {
  $s = ConvertTo-Json -InputObject $obj -Depth 6 -Compress
  if (-not $s) { $s = 'null' }
  Enviar $ctx $code ([Text.Encoding]::UTF8.GetBytes($s)) 'application/json; charset=utf-8'
}
function Corpo($ctx) {
  $sr = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
  $t = $sr.ReadToEnd(); $sr.Close()
  if ($t) { return ($t | ConvertFrom-Json) } else { return $null }
}
function Confirmado($b) { return ($b -and $b.confirma -eq 'SIM SIM') }
function DentroDoUsuario($p) {
  try { $f = [IO.Path]::GetFullPath($p) } catch { return $false }
  return $f.StartsWith($env:USERPROFILE + '\', [StringComparison]::OrdinalIgnoreCase)
}

# ---------- informacoes ----------
function Info {
  $ips = Lista (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254*' } | ForEach-Object { $_.IPAddress })
  $os = Get-CimInstance Win32_OperatingSystem
  return @{ admin = (SouAdmin); pc = $env:COMPUTERNAME; usuario = $env:USERNAME; windows = $(if ($os) { $os.Caption } else { '' }); livreC = (Livre); totalC = [double]((Get-PSDrive -Name C).Used + (Livre)); codigo = $Codigo; porta = $script:Porta; ips = $ips; wifi = $script:WifiPossivel; recebendo = $script:Recebendo; pastaCel = $script:PastaCel; casa = $Casa; perfil = $env:USERPROFILE }
}

function Saude {
  $os = Get-CimInstance Win32_OperatingSystem
  $mem = $null
  if ($os) { $mem = @{ usado = [double](($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) * 1KB); total = [double]($os.TotalVisibleMemorySize * 1KB); ligadoDesde = [string]$os.LastBootUpTime } }
  $discos = Lista (Get-PhysicalDisk -ErrorAction SilentlyContinue | ForEach-Object { @{ nome = $_.FriendlyName; tipo = [string]$_.MediaType; saude = [string]$_.HealthStatus; estado = [string]$_.OperationalStatus; tamanho = [double]$_.Size } })
  $unid = Lista (Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Used -or $_.Free } | ForEach-Object { @{ letra = $_.Name; usado = [double]$_.Used; livre = [double]$_.Free } })
  $procs = Lista (Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 15 | ForEach-Object { @{ nome = $_.ProcessName; mb = [math]::Round($_.WorkingSet64 / 1MB) } })
  $inicio = Lista (Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | ForEach-Object { @{ nome = $_.Name; onde = $_.Location; comando = $_.Command } })
  $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
  $av = $null
  if ($mp) { $av = @{ ligado = $mp.AntivirusEnabled; tempoReal = $mp.RealTimeProtectionEnabled; vacinas = [string]$mp.AntivirusSignatureLastUpdated; ultimaVerificacao = [string]$mp.QuickScanEndTime } }
  $tele = Lista (foreach ($n in 'DiagTrack', 'dmwappushservice', 'WerSvc') { $s = Get-Service -Name $n -ErrorAction SilentlyContinue; if ($s) { @{ nome = $s.DisplayName; id = $n; status = [string]$s.Status; inicio = [string]$s.StartType } } })
  $atual = Lista (Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 5 | ForEach-Object { @{ id = $_.HotFixID; quando = [string]$_.InstalledOn } })
  $impr = Lista (Get-Printer -ErrorAction SilentlyContinue | ForEach-Object { @{ nome = $_.Name; driver = $_.DriverName; porta = $_.PortName; status = [string]$_.PrinterStatus } })
  $h = Get-Item -LiteralPath 'C:\hiberfil.sys' -Force -ErrorAction SilentlyContinue
  $lix = 0; try { (New-Object -ComObject Shell.Application).NameSpace(10).Items() | ForEach-Object { $lix += $_.Size } } catch {}
  $dfs = Join-Path $env:LOCALAPPDATA 'Google\DriveFS'
  $od = Get-Process -Name OneDrive -ErrorAction SilentlyContinue
  return @{ memoria = $mem; discos = $discos; unidades = $unid; programasMemoria = $procs; ligamSozinhos = $inicio; antivirus = $av; telemetria = $tele; atualizacoes = $atual; impressoras = $impr;
    espaco = @{ hibernacao = $(if ($h) { [double]$h.Length } else { 0 }); temporarios = (Tam $env:TEMP); lixeira = [double]$lix; driveFS = (Tam $dfs); windowsOld = (Tam 'C:\Windows.old') }; oneDriveRodando = [bool]$od }
}

function Pastas($b) {
  $p = $env:USERPROFILE
  if ($b -and $b.pasta) { $p = [string]$b.pasta }
  if (-not (Test-Path -LiteralPath $p)) { return @{ erro = 'Nao achei a pasta ' + $p } }
  $itens = Lista (Get-ChildItem -LiteralPath $p -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object { @{ nome = $_.Name; caminho = $_.FullName; bytes = (Tam $_.FullName) } })
  $soltos = (Get-ChildItem -LiteralPath $p -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
  $grandes = Lista (Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 200MB } | Sort-Object Length -Descending | Select-Object -First 20 | ForEach-Object { @{ caminho = $_.FullName; bytes = [double]$_.Length } })
  return @{ pasta = $p; pai = (Split-Path $p -Parent); pastas = Lista ($itens | Sort-Object { $_.bytes } -Descending); arquivosSoltos = [double]$soltos; grandes = $grandes }
}

function Programas {
  $chaves = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
  $vistos = @{}
  $l = foreach ($k in $chaves) {
    Get-ItemProperty -Path $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -and -not $_.SystemComponent } | ForEach-Object {
      if (-not $vistos.ContainsKey($_.DisplayName)) {
        $vistos[$_.DisplayName] = 1
        @{ nome = [string]$_.DisplayName; versao = [string]$_.DisplayVersion; fabricante = [string]$_.Publisher; mb = $(if ($_.EstimatedSize) { [math]::Round($_.EstimatedSize / 1024) } else { 0 }); instalado = [string]$_.InstallDate }
      }
    }
  }
  return @{ programas = Lista ($l | Sort-Object { $_.mb } -Descending) }
}

function Repetidos($b) {
  $pastas = @([Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Downloads'))
  if ($b -and $b.pasta) { $pastas = @([string]$b.pasta) }
  $arqs = foreach ($pp in $pastas) { Get-ChildItem -LiteralPath $pp -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 100KB -and $_.FullName -notlike ($Quarentena + '*') } }
  $grupos = @()
  $sobra = 0
  foreach ($g in ($arqs | Group-Object Length | Where-Object { $_.Count -gt 1 })) {
    $porHash = $g.Group | ForEach-Object { [pscustomobject]@{ F = $_; H = (Get-FileHash -LiteralPath $_.FullName -Algorithm MD5 -ErrorAction SilentlyContinue).Hash } } | Where-Object { $_.H } | Group-Object H | Where-Object { $_.Count -gt 1 }
    foreach ($h in $porHash) {
      $fs = Lista ($h.Group | Sort-Object { $_.F.LastWriteTime } | ForEach-Object { @{ caminho = $_.F.FullName; data = $_.F.LastWriteTime.ToString('dd/MM/yyyy HH:mm') } })
      $grupos += , @{ bytes = [double]$h.Group[0].F.Length; arquivos = $fs }
      $sobra += $h.Group[0].F.Length * ($h.Count - 1)
    }
  }
  return @{ pastas = $pastas; grupos = Lista ($grupos | Sort-Object { $_.bytes } -Descending); liberaria = [double]$sobra }
}

function ParaQuarentena($b) {
  $dia = Join-Path $Quarentena (Get-Date -Format 'yyyy-MM-dd_HHmm')
  New-Item -ItemType Directory -Force -Path $dia | Out-Null
  $ok = 0; $pul = @()
  foreach ($a in (Lista $b.arquivos)) {
    $a = [string]$a
    if (-not (DentroDoUsuario $a) -or -not (Test-Path -LiteralPath $a -PathType Leaf)) { $pul += $a; continue }
    $dest = Join-Path $dia (Split-Path $a -Leaf); $i = 2
    while (Test-Path -LiteralPath $dest) { $dest = Join-Path $dia ([IO.Path]::GetFileNameWithoutExtension($a) + ' (' + $i + ')' + [IO.Path]::GetExtension($a)); $i++ }
    try { Move-Item -LiteralPath $a -Destination $dest -ErrorAction Stop; Add-Content -LiteralPath (Join-Path $dia 'de-onde-veio.txt') -Value ((Split-Path $dest -Leaf) + '  <=  ' + $a) -Encoding UTF8; $ok++ } catch { $pul += $a }
  }
  Log ('Quarentena: ' + $ok + ' arquivos em ' + $dia)
  return @{ movidos = $ok; pulados = $pul; pasta = $dia }
}
function VerQuarentena { return @{ pasta = $Quarentena; bytes = (Tam $Quarentena); arquivos = (Get-ChildItem -LiteralPath $Quarentena -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'de-onde-veio.txt' } | Measure-Object).Count } }

function Limpar($b) {
  if (-not (Confirmado $b)) { return @{ erro = 'Precisa confirmar com SIM duas vezes.' } }
  $antes = Livre
  switch ([string]$b.oque) {
    'temporarios' {
      Get-ChildItem -LiteralPath $env:TEMP -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
      if (SouAdmin) { Get-ChildItem -LiteralPath 'C:\Windows\Temp' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
    }
    'lixeira' { Clear-RecycleBin -Force -ErrorAction SilentlyContinue }
    'quarentena' { if (Test-Path -LiteralPath $Quarentena) { Get-ChildItem -LiteralPath $Quarentena -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue } }
    'hibernacao' { if (SouAdmin) { powercfg /h off | Out-Null; Start-Sleep -Seconds 2 } else { return @{ erro = 'Precisa de administrador.' } } }
    default { return @{ erro = 'Nao sei limpar isso.' } }
  }
  $lib = (Livre) - $antes
  Log ('Limpou ' + $b.oque + ': ' + (GB $lib))
  return @{ ok = $true; liberou = [double]$lib }
}

function Virus {
  $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
  $amea = Lista (Get-MpThreatDetection -ErrorAction SilentlyContinue | Select-Object -First 30 | ForEach-Object { $id = $_.ThreatID; $nome = (Get-MpThreat -ThreatID $id -ErrorAction SilentlyContinue).ThreatName; @{ nome = [string]$nome; quando = [string]$_.InitialDetectionTime; arquivos = Lista $_.Resources; acao = [string]$_.ActionSuccess } })
  $j = $script:Jobs['virus']
  return @{ ligado = $(if ($mp) { $mp.AntivirusEnabled } else { $null }); tempoReal = $(if ($mp) { $mp.RealTimeProtectionEnabled } else { $null }); vacinas = $(if ($mp) { [string]$mp.AntivirusSignatureLastUpdated } else { '' }); ultimaRapida = $(if ($mp) { [string]$mp.QuickScanEndTime } else { '' }); ameacas = $amea; verificando = $(if ($j) { [string]$j.State } else { '' }) }
}

function HD {
  $discos = Lista (Get-Disk -ErrorAction SilentlyContinue | ForEach-Object { @{ numero = $_.Number; nome = $_.FriendlyName; tamanho = [double]$_.Size; conexao = [string]$_.BusType; estado = [string]$_.OperationalStatus; saude = [string]$_.HealthStatus; desligado = $_.IsOffline; particao = [string]$_.PartitionStyle } })
  $vol = Lista (Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.Size -gt 0 } | ForEach-Object { @{ letra = [string]$_.DriveLetter; nome = $_.FileSystemLabel; sistema = $_.FileSystem; tipo = [string]$_.DriveType; tamanho = [double]$_.Size; livre = [double]$_.SizeRemaining; saude = [string]$_.HealthStatus } })
  $prob = Lista (Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.Status -ne 'OK' } | ForEach-Object { @{ nome = $_.FriendlyName; classe = $_.Class; status = [string]$_.Status } })
  $usb = Lista (Get-PnpDevice -PresentOnly -Class DiskDrive, USB, WPD -ErrorAction SilentlyContinue | ForEach-Object { @{ nome = $_.FriendlyName; classe = $_.Class; status = [string]$_.Status } })
  return @{ discos = $discos; volumes = $vol; comProblema = $prob; usb = $usb }
}

function Portas {
  $vistos = @{}
  Get-NetTCPConnection -State Listen, Established -ErrorAction SilentlyContinue | ForEach-Object {
    $pr = (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName
    if (-not $pr) { $pr = '?' }
    $k = $pr + '|' + $_.State
    if (-not $vistos.ContainsKey($k)) { $vistos[$k] = @{ programa = $pr; estado = $(if ([string]$_.State -eq 'Listen') { 'porta aberta (esperando)' } else { 'conectado na internet' }); vezes = 0; portas = @() } }
    $vistos[$k].vezes++
    if ([string]$_.State -eq 'Listen' -and $vistos[$k].portas.Count -lt 6) { $vistos[$k].portas += $_.LocalPort } elseif ($vistos[$k].portas.Count -lt 4) { $vistos[$k].portas += ($_.RemoteAddress + ':' + $_.RemotePort) }
  }
  return @{ conexoes = Lista ($vistos.Values | Sort-Object { $_.vezes } -Descending) }
}

function MS($b) {
  $ac = [string]$b.acao
  $tele = @('DiagTrack', 'dmwappushservice')
  $pol = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'
  $run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
  if ($ac -ne 'ver' -and -not (SouAdmin) -and $ac -notin @('onedrive-parar', 'onedrive-nao-iniciar')) { return @{ erro = 'Precisa de administrador. Feche e abra de novo clicando SIM.' } }
  if ($ac -in @('telemetria-desligar', 'onedrive-desinstalar', 'compartilhamento-parar') -and -not (Confirmado $b)) { return @{ erro = 'Precisa confirmar com SIM duas vezes.' } }
  switch ($ac) {
    'telemetria-desligar' {
      foreach ($n in $tele) { Stop-Service -Name $n -Force -ErrorAction SilentlyContinue; Set-Service -Name $n -StartupType Disabled -ErrorAction SilentlyContinue }
      New-Item -Path $pol -Force | Out-Null; Set-ItemProperty -Path $pol -Name AllowTelemetry -Value 0 -Type DWord
      Log 'Telemetria desligada'
    }
    'telemetria-religar' {
      foreach ($n in $tele) { Set-Service -Name $n -StartupType Automatic -ErrorAction SilentlyContinue; Start-Service -Name $n -ErrorAction SilentlyContinue }
      Remove-ItemProperty -Path $pol -Name AllowTelemetry -ErrorAction SilentlyContinue
      Log 'Telemetria religada'
    }
    'onedrive-parar' { Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue; Log 'OneDrive parado' }
    'onedrive-nao-iniciar' { Remove-ItemProperty -Path $run -Name OneDrive -ErrorAction SilentlyContinue; Log 'OneDrive nao inicia mais com o Windows' }
    'onedrive-desinstalar' {
      Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue
      $ex = @("$env:SystemRoot\System32\OneDriveSetup.exe", "$env:SystemRoot\SysWOW64\OneDriveSetup.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
      if ($ex) { Start-Process -FilePath $ex -ArgumentList '/uninstall' -Wait } else { winget uninstall --id Microsoft.OneDrive --silent --accept-source-agreements | Out-Null }
      Log 'OneDrive desinstalado'
    }
    'compartilhamento-parar' {
      $nome = [string]$b.nome
      if ($nome -and $nome -notmatch '\$$') { Remove-SmbShare -Name $nome -Force -ErrorAction SilentlyContinue; Log ('Parou de compartilhar ' + $nome) }
    }
  }
  $sv = Lista (foreach ($n in $tele) { $x = Get-Service -Name $n -ErrorAction SilentlyContinue; if ($x) { @{ id = $n; nome = $x.DisplayName; status = [string]$x.Status; inicio = [string]$x.StartType } } })
  $odp = Join-Path $env:USERPROFILE 'OneDrive'
  $od = @{ rodando = [bool](Get-Process -Name OneDrive -ErrorAction SilentlyContinue); iniciaSozinho = [bool](Get-ItemProperty -Path $run -Name OneDrive -ErrorAction SilentlyContinue); pasta = $odp; existePasta = (Test-Path $odp) }
  $sh = Lista (Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '\$$' } | ForEach-Object { @{ nome = $_.Name; pasta = $_.Path; descricao = $_.Description } })
  $pol0 = (Get-ItemProperty -Path $pol -Name AllowTelemetry -ErrorAction SilentlyContinue).AllowTelemetry
  return @{ telemetria = $sv; politica = $pol0; onedrive = $od; compartilhadas = $sh }
}

function Terminal($b) {
  $cmd = [string]$b.cmd
  if (-not $cmd.Trim()) { return @{ saida = '' } }
  Log ('TERMINAL: ' + $cmd)
  $j = Start-Job -ScriptBlock { param($c) Set-Location $env:USERPROFILE; try { Invoke-Expression $c 2>&1 | Out-String -Width 220 } catch { 'ERRO: ' + $_ } } -ArgumentList $cmd
  $fim = Wait-Job -Job $j -Timeout 120
  if (-not $fim) { Stop-Job $j; Remove-Job $j -Force; return @{ saida = '(o comando demorou mais de 2 minutos e eu parei. Comandos que ficam esperando resposta nao funcionam aqui.)' } }
  $s = (Receive-Job $j 2>&1 | Out-String)
  Remove-Job $j -Force
  if ($s.Length -gt 60000) { $s = $s.Substring(0, 60000) + "`n... (cortei, era grande demais)" }
  return @{ saida = $s }
}

function Copiar($b) {
  $o = [string]$b.origem; $d = [string]$b.destino
  if (-not (Test-Path -LiteralPath $o)) { return @{ erro = 'Nao achei a pasta de origem.' } }
  if (-not $d -or -not (Test-Path -LiteralPath (Split-Path $d -Qualifier))) { return @{ erro = 'Nao achei o destino (o HD esta ligado?).' } }
  $logc = Join-Path $Casa 'copia.log'
  $script:Jobs['copia'] = Start-Job -ScriptBlock { param($o, $d, $l) robocopy "$o" "$d" /E /R:1 /W:1 /XJ /NP /LOG:"$l" | Out-Null; $LASTEXITCODE } -ArgumentList $o, $d, $logc
  Log ('COPIA: ' + $o + ' -> ' + $d)
  return @{ ok = $true }
}
function EstadoCopia {
  $j = $script:Jobs['copia']
  $logc = Join-Path $Casa 'copia.log'
  $fim = ''
  if (Test-Path -LiteralPath $logc) { $fim = (Get-Content -LiteralPath $logc -Tail 14 -ErrorAction SilentlyContinue) -join "`n" }
  return @{ estado = $(if ($j) { [string]$j.State } else { '' }); fim = $fim }
}

function Recepcao($b) {
  if (-not $script:WifiPossivel) { return @{ erro = 'A recepcao pelo Wi-Fi precisa de administrador. Feche e abra de novo clicando SIM.' } }
  if ($b.pasta) { $script:PastaCel = [string]$b.pasta }
  $script:Recebendo = [bool]$b.ligar
  $nomeRegra = 'Faxina PC - receber do celular'
  try {
    Get-NetFirewallRule -DisplayName $nomeRegra -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    if ($script:Recebendo) { New-NetFirewallRule -DisplayName $nomeRegra -Direction Inbound -Protocol TCP -LocalPort $script:Porta -Action Allow -Profile Any | Out-Null }
  } catch { Log ('firewall: ' + $_) }
  if ($script:Recebendo) { New-Item -ItemType Directory -Force -Path $script:PastaCel | Out-Null }
  Log ('Recepcao ' + $script:Recebendo + ' em ' + $script:PastaCel)
  return (Info)
}

function Limpo($s) { $s = [string]$s; $s = ($s -replace '[\\/:*?"<>|\x00-\x1f]', '_').Trim().Trim('.'); if (-not $s) { $s = 'arquivo' }; return $s }
function Celular($ctx, $path) {
  $req = $ctx.Request
  if ($path -eq '/celular' -or $path -eq '/celular/') {
    Enviar $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $Aqui 'celular.html'))) 'text/html; charset=utf-8'; return
  }
  if ($path -eq '/celular/enviar' -and $req.HttpMethod -eq 'POST') {
    if (-not $script:Recebendo) { Json $ctx @{ erro = 'A recepcao esta desligada no PC.' } 403; return }
    if ($req.Headers['X-Codigo'] -ne $Codigo) { Json $ctx @{ erro = 'Codigo errado. Olhe o codigo no painel do PC.' } 403; return }
    $nome = Limpo (Split-Path ([Uri]::UnescapeDataString([string]$req.Headers['X-Nome'])) -Leaf)
    $sub = ''
    if ($req.Headers['X-Pasta']) { $sub = Limpo ([Uri]::UnescapeDataString([string]$req.Headers['X-Pasta'])) }
    $dir = $script:PastaCel; if ($sub) { $dir = Join-Path $dir $sub }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $dest = Join-Path $dir $nome
    $tam = [double]$req.ContentLength64
    if ((Test-Path -LiteralPath $dest) -and (Get-Item -LiteralPath $dest).Length -eq $tam) { $req.InputStream.CopyTo([IO.Stream]::Null); Json $ctx @{ ok = $true; pulado = $true }; return }
    $i = 2
    while (Test-Path -LiteralPath $dest) { $dest = Join-Path $dir ([IO.Path]::GetFileNameWithoutExtension($nome) + ' (' + $i + ')' + [IO.Path]::GetExtension($nome)); $i++ }
    $fs = [IO.File]::Create($dest)
    try { $req.InputStream.CopyTo($fs) } finally { $fs.Close() }
    $gravou = (Get-Item -LiteralPath $dest).Length
    Json $ctx @{ ok = ($gravou -eq $tam -or $tam -le 0); bytes = [double]$gravou }
    return
  }
  Json $ctx @{ erro = 'nao existe' } 404
}

function Atender($ctx) {
  $req = $ctx.Request
  $path = $req.Url.AbsolutePath
  if ($path -like '/celular*') { Celular $ctx $path; return }
  if (-not [Net.IPAddress]::IsLoopback($req.RemoteEndPoint.Address)) { Json $ctx @{ erro = 'So funciona no proprio PC.' } 403; return }
  if ($path -eq '/' -or $path -eq '/index.html') { Enviar $ctx 200 ([IO.File]::ReadAllBytes((Join-Path $Aqui 'painel.html'))) 'text/html; charset=utf-8'; return }
  if ($req.Headers['X-Token'] -ne $Token) { Json $ctx @{ erro = 'Abra o painel pelo programa (o endereco mudou).' } 403; return }
  $b = $null
  if ($req.HttpMethod -eq 'POST') { $b = Corpo $ctx }
  switch ($path) {
    '/api/info' { Json $ctx (Info) }
    '/api/saude' { Json $ctx (Saude) }
    '/api/pastas' { Json $ctx (Pastas $b) }
    '/api/programas' { Json $ctx (Programas) }
    '/api/repetidos' { Json $ctx (Repetidos $b) }
    '/api/quarentena' { Json $ctx (ParaQuarentena $b) }
    '/api/ver-quarentena' { Json $ctx (VerQuarentena) }
    '/api/limpar' { Json $ctx (Limpar $b) }
    '/api/virus' { Json $ctx (Virus) }
    '/api/virus-verificar' { $script:Jobs['virus'] = Start-Job -ScriptBlock { Start-MpScan -ScanType QuickScan }; Log 'Verificacao rapida de virus'; Json $ctx @{ ok = $true } }
    '/api/hd' { Json $ctx (HD) }
    '/api/ms' { Json $ctx (MS $b) }
    '/api/portas' { Json $ctx (Portas) }
    '/api/terminal' { Json $ctx (Terminal $b) }
    '/api/copiar' { Json $ctx (Copiar $b) }
    '/api/copia-estado' { Json $ctx (EstadoCopia) }
    '/api/recepcao' { Json $ctx (Recepcao $b) }
    '/api/abrir' { if ($b.pasta -and (Test-Path -LiteralPath ([string]$b.pasta))) { Start-Process explorer.exe -ArgumentList ('"' + [string]$b.pasta + '"') }; Json $ctx @{ ok = $true } }
    '/api/programas-windows' { Start-Process appwiz.cpl; Json $ctx @{ ok = $true } }
    '/api/limpeza-windows' { Start-Process cleanmgr.exe -ArgumentList '/d C'; Json $ctx @{ ok = $true } }
    '/api/sair' { Json $ctx @{ ok = $true }; $script:Sair = $true }
    default { Json $ctx @{ erro = 'nao existe' } 404 }
  }
}

# ---------- ligar ----------
$L = $null
$script:WifiPossivel = $false
foreach ($p in 8765..8775) {
  foreach ($pref in $(if (SouAdmin) { @('+', '127.0.0.1') } else { @('127.0.0.1') })) {
    $t = New-Object System.Net.HttpListener
    $t.Prefixes.Add('http://' + $pref + ':' + $p + '/')
    try { $t.Start(); $L = $t; $script:Porta = $p; $script:WifiPossivel = ($pref -eq '+'); break } catch { try { $t.Close() } catch {} }
  }
  if ($L) { break }
}
if (-not $L) { Write-Host 'Nao consegui ligar o painel (portas 8765 a 8775 ocupadas). Reinicie o PC e tente de novo.' -ForegroundColor Red; Log 'sem porta'; return }

$url = 'http://127.0.0.1:' + $script:Porta + '/?t=' + $Token
Log ('Painel ligado em ' + $url.Split('?')[0] + ' admin=' + (SouAdmin))
Clear-Host
Write-Host ''
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host '   FAXINA PC - o painel abriu no navegador' -ForegroundColor Cyan
Write-Host '  ==================================================' -ForegroundColor Cyan
Write-Host ('   Administrador: ' + $(if (SouAdmin) { 'SIM' } else { 'NAO' }))
Write-Host '   NAO FECHE esta janela enquanto usa o painel.'
Write-Host '   Se o navegador nao abriu, copie este endereco:'
Write-Host ('   ' + $url) -ForegroundColor Yellow
Write-Host '   Para sair: botao "Desligar" no painel, ou feche esta janela.'
Write-Host ''
try { Start-Process ('microsoft-edge:' + $url) -ErrorAction Stop } catch { Start-Process $url }

$script:Sair = $false
while ($L.IsListening -and -not $script:Sair) {
  try { $ctx = $L.GetContext() } catch { break }
  try { Atender $ctx } catch { Log ('ERRO: ' + $_ + ' em ' + $_.InvocationInfo.PositionMessage); try { Json $ctx @{ erro = [string]$_ } 500 } catch {} }
}
try { Get-NetFirewallRule -DisplayName 'Faxina PC - receber do celular' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue } catch {}
try { $L.Stop() } catch {}
Write-Host '  Painel desligado. Pode fechar esta janela.' -ForegroundColor Cyan
