@echo off
title Faxina PC
cd /d "%~dp0"
if not exist "%~dp0faxina-pc.ps1" (
  echo.
  echo  Tire os arquivos de dentro do ZIP primeiro: botao direito no zip, Extrair tudo.
  echo.
  pause
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0faxina-pc.ps1"
if errorlevel 1 pause
